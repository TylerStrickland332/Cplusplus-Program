#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

class WordFrequencyAnalyzer {
private: //Declares input an output files
    const string inputFilename = "CS210_Project_Three_Input_File.txt";
    const string outputFilename = "frequency.dat";
    map<string, int> wordCount;

    // Function to count the frequency of words in the input file
    void countWords() {
        ifstream inputFile(inputFilename);
        string word;

        while (inputFile >> word) {
            // Increment the count for each word encountered
            wordCount[word]++;
        }

        inputFile.close();
    }

public:
    // Function to analyze word frequency based on user input
    void analyzeFrequency() {
        countWords();

        while (true) { //Main menu
            cout << "Choose an option:\n"
                << "1. Enter a word to check its frequency\n"
                << "2. Output frequency.dat contents\n"
                << "3. Output frequency of every word using stars\n"
                << "End. Exit the program\n";
            string option;
            cin >> option;

            if (option == "1") { //Option 1 menu
                string word;
                cout << "Enter a word: ";
                cin >> word;
                if (wordCount.find(word) != wordCount.end()) {
                    cout << word << " " << wordCount[word] << endl;
                }
                else {
                    cout << "Word not found in input file." << endl;
                }
            }
            else if (option == "2") { //Option 2 menu
                ifstream outputFile(outputFilename);
                string line;
                while (getline(outputFile, line)) {
                    cout << line << endl;
                }
                outputFile.close();
            }
            else if (option == "3") { //Option 3 menu
                for (const auto& entry : wordCount) {
                    cout << entry.first << " ";
                    for (int i = 0; i < entry.second; ++i) {
                        cout << "*";
                    }
                    cout << endl;
                }
            }
            else if (option == "End") { //End program menu option
                break;
            }
            else {
                cout << "Invalid option. Please try again." << endl; //Outputs if menu choice is invalid
            }
        }
    }
};

int main() {
    WordFrequencyAnalyzer analyzer;
    analyzer.analyzeFrequency();
    return 0;
}